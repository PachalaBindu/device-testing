const {remote} = require('webdriverio');

const capabilities = {
  platformName: 'Android',
  'appium:automationName': 'UiAutomator2',
  'appium:deviceName': 'Android',
  browserName: 'Chrome',
};

const wdOpts = {
  hostname: process.env.APPIUM_HOST || 'localhost',
  port: parseInt(process.env.APPIUM_PORT, 10) || 4723,
  logLevel: 'info',
  capabilities,
};

async function runTest() {
  const driver = await remote(wdOpts);
  try {
    driver.url('https://testhealthapp.discovery.co.za/');
    await driver.pause(20000);
    const button = await driver.$('#blue-button');
    driver.executeScript("arguments[0].click();", [button]);
    
    await driver.pause(5000); 

    const username=await driver.$("#Username");
    const password=await driver.$("#Password");
    username.setValue("test--kathan");
    password.setValue("feedmeseymour1");
     
    await driver.pause(5000); 
    
    const loginButton=await driver.$("#btnLogin");
    loginButton.click();

  } finally {
    await driver.pause(20000);
    await driver.deleteSession();
  }
}

runTest().catch(console.error);